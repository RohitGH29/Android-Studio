package com.ritech.calltank;

public class Constant {
    public static final String FOLDER_NAME="/Call/";
    public static final String SAVE_FOLDER_NAME="/StatusSaver/";

}
