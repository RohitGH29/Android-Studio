package com.ritech.calltank;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;

import com.ritech.calltank.Adapters.Adapter;

import java.io.File;
import java.util.ArrayList;

public class AudioActivity extends AppCompatActivity {

    Adapter adapter;
    RecyclerView recyclerView;

    File[] files;
    ArrayList<ModelClass> fileslist=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio);


        recyclerView = findViewById(R.id.recyclerview);
        setuplayout();

    }

    private void setuplayout() {

        fileslist.clear();
       // recyclerView.setHasFixedSize(true);
       // StaggeredGridLayoutManager staggeredGridLayoutManager=new StaggeredGridLayoutManager(3,StaggeredGridLayoutManager.VERTICAL);

        //recyclerView.setLayoutManager(staggeredGridLayoutManager);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new Adapter(AudioActivity.this,getData());
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();



    }

    private ArrayList<ModelClass> getData() {

        ModelClass f;
        String targetpath= Environment.getExternalStorageDirectory().getAbsolutePath()+Constant.FOLDER_NAME;
        File targetdir=new File(targetpath);
        files=targetdir.listFiles();
        for (int i=0;i<files.length;i++)
        {
            File file=files[i];
            f=new ModelClass();
            f.setUri(Uri.fromFile(file));
            f.setPath(files[i].getAbsolutePath());
            f.setFilename(file.getName());
            if (! f.getUri().toString().endsWith(".nomedia"))
            {
                fileslist.add(f);
            }
        }
        return  fileslist;
    }


}