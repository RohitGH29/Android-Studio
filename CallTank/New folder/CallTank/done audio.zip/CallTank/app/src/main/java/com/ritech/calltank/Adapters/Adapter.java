package com.ritech.calltank.Adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Picture;
import android.media.MediaPlayer;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.ritech.calltank.Constant;
import com.ritech.calltank.ModelClass;
import com.ritech.calltank.R;

import java.io.IOException;
import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {


    Context context;
    ArrayList<ModelClass> fileslist;

    public Adapter(Context context, ArrayList<ModelClass> fileslist) {
        this.context = context;
        this.fileslist = fileslist;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_layout,parent,false);
        return new ViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        final ModelClass modelClass=fileslist.get(position);
        if (modelClass.getUri().toString().endsWith(".mp3"))
        {
           // holder.play.setVisibility(View.VISIBLE);
        }
        else
        {
            //holder.play.setVisibility(View.INVISIBLE);
        }

        //Glide.with(context).load(modelClass.getUri()).into(holder.mainstatus);

        holder.play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    //holder.player.start();

                MediaPlayer mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(modelClass.getUri().toString());
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                                  mp.start();
                        }
                    });
                    mediaPlayer.prepare();

                }catch (IOException e)
                {
                    e.printStackTrace();
                }



            }
        });





    }

    @Override
    public int getItemCount() {
        return fileslist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView play;
        MediaPlayer player;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            play=itemView.findViewById(R.id.play);
            //player= MediaPlayer.create(this,fileslist,);

            player = new MediaPlayer();

        }
    }
}
